require(['/nouislider/distribute/nouislider.js'], function(noUiSlider) {
    console.log(noUiSlider); // { create, version, ... }
});
